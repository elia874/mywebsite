// ============================================================================
// Interceptor - app.js
// Talks to the burpclone addon.py control API running on your VPS.
// ============================================================================

const state = {
  base: null,          // e.g. "https://1.2.3.4:8081"
  wsBase: null,         // e.g. "wss://1.2.3.4:8081"
  token: null,
  ws: null,
  flows: [],
  flowsById: {},
  repeaterTabs: [],
  activeRepTab: 0,
  intruderResults: [],
};

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));

// ---------------------------------------------------------------------------
// Base64 helpers (UTF-8 safe)
// ---------------------------------------------------------------------------

function b64decode(b64) {
  try {
    const bin = atob(b64 || "");
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new TextDecoder("utf-8", { fatal: false }).decode(bytes);
  } catch {
    return "";
  }
}

function b64encode(str) {
  const bytes = new TextEncoder().encode(str || "");
  let bin = "";
  bytes.forEach((b) => (bin += String.fromCharCode(b)));
  return btoa(bin);
}

function headersToText(headers) {
  return (headers || []).map(([k, v]) => `${k}: ${v}`).join("\n");
}

function textToHeaders(text) {
  return (text || "")
    .split("\n")
    .map((l) => l.trim())
    .filter(Boolean)
    .map((l) => {
      const idx = l.indexOf(":");
      if (idx === -1) return [l, ""];
      return [l.slice(0, idx).trim(), l.slice(idx + 1).trim()];
    });
}

function fetchApi(path, opts = {}) {
  const url = new URL(state.base + path);
  url.searchParams.set("token", state.token);
  for (const [k, v] of Object.entries(opts.params || {})) {
    if (v !== undefined && v !== null) url.searchParams.set(k, v);
  }
  return fetch(url, {
    method: opts.method || "GET",
    headers: opts.body ? { "Content-Type": "application/json" } : undefined,
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
}

// ---------------------------------------------------------------------------
// Connect screen
// ---------------------------------------------------------------------------

function loadSavedConnection() {
  const saved = localStorage.getItem("interceptor_conn");
  if (!saved) return null;
  try { return JSON.parse(saved); } catch { return null; }
}

function saveConnection(conn) {
  localStorage.setItem("interceptor_conn", JSON.stringify(conn));
}

async function tryConnect(host, token, useTls) {
  const proto = useTls ? "https" : "http";
  const wsProto = useTls ? "wss" : "ws";
  state.base = `${proto}://${host}`;
  state.wsBase = `${wsProto}://${host}`;
  state.token = token;

  const resp = await fetchApi("/api/flows", { params: { limit: 50 } });
  if (!resp.ok) throw new Error(`HTTP ${resp.status} - check token/address`);
  return resp.json();
}

$("#btn-connect").addEventListener("click", async () => {
  const host = $("#inp-host").value.trim().replace(/^https?:\/\//, "").replace(/\/$/, "");
  const token = $("#inp-token").value.trim();
  const useTls = $("#inp-tls").checked;
  const errEl = $("#connect-error");
  errEl.textContent = "";

  if (!host || !token) {
    errEl.textContent = "Enter both address and token.";
    return;
  }

  $("#btn-connect").textContent = "Connecting…";
  try {
    const flows = await tryConnect(host, token, useTls);
    saveConnection({ host, token, useTls });
    state.flows = flows;
    flows.forEach((f) => (state.flowsById[f.id] = f));
    enterApp();
  } catch (e) {
    errEl.textContent = e.message || "Could not connect.";
  } finally {
    $("#btn-connect").textContent = "Connect";
  }
});

// ---------------------------------------------------------------------------
// App entry
// ---------------------------------------------------------------------------

function enterApp() {
  $("#screen-connect").classList.add("hidden");
  $("#screen-app").classList.remove("hidden");
  renderFlowList();
  connectWs();
  addRepeaterTab();
}

function connectWs() {
  if (state.ws) { try { state.ws.close(); } catch {} }
  const ws = new WebSocket(`${state.wsBase}/api/ws?token=${encodeURIComponent(state.token)}`);
  state.ws = ws;

  ws.onopen = () => setConnDot(true);
  ws.onclose = () => { setConnDot(false); setTimeout(connectWs, 3000); };
  ws.onerror = () => setConnDot(false);

  ws.onmessage = (evt) => {
    let msg;
    try { msg = JSON.parse(evt.data); } catch { return; }
    if (msg.type === "flow" || msg.type === "intercepted") {
      const f = msg.flow;
      state.flowsById[f.id] = f;
      if (!state.flows.find((x) => x.id === f.id)) state.flows.push(f);
      renderFlowList();
    } else if (msg.type === "intruder_result") {
      state.intruderResults.push(msg.result);
      renderIntruderResults();
    }
  };

  // keepalive ping every 25s
  clearInterval(ws._pingInterval);
  ws._pingInterval = setInterval(() => {
    if (ws.readyState === WebSocket.OPEN) ws.send("ping");
  }, 25000);
}

function setConnDot(ok) {
  $("#conn-dot").classList.toggle("off", !ok);
  $("#conn-label").textContent = ok ? "connected" : "reconnecting…";
}

// auto-reconnect on load if we have a saved connection
(async function init() {
  const saved = loadSavedConnection();
  if (saved) {
    $("#inp-host").value = saved.host;
    $("#inp-token").value = saved.token;
    $("#inp-tls").checked = saved.useTls;
    try {
      const flows = await tryConnect(saved.host, saved.token, saved.useTls);
      state.flows = flows;
      flows.forEach((f) => (state.flowsById[f.id] = f));
      enterApp();
    } catch {
      // fall through to connect screen, fields are pre-filled
    }
  }
  registerServiceWorker();
})();

function registerServiceWorker() {
  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("sw.js").catch(() => {});
  }
}

$("#btn-settings").addEventListener("click", () => {
  if (confirm("Disconnect and return to the connect screen?")) {
    localStorage.removeItem("interceptor_conn");
    location.reload();
  }
});

// ---------------------------------------------------------------------------
// Tab switching
// ---------------------------------------------------------------------------

$$(".tabbar-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    $$(".tabbar-btn").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    const tab = btn.dataset.tab;
    $$(".tab-pane").forEach((p) => p.classList.add("hidden"));
    $(`#tab-${tab}`).classList.remove("hidden");
  });
});

// ---------------------------------------------------------------------------
// PROXY TAB
// ---------------------------------------------------------------------------

function methodBadgeClass(method) {
  const m = (method || "").toLowerCase();
  if (m === "get") return "badge-get";
  if (m === "post") return "badge-post";
  if (m === "put" || m === "patch") return "badge-put";
  if (m === "delete") return "badge-delete";
  return "badge-other";
}

function statusClass(code) {
  if (!code) return "";
  if (code < 300) return "status-2xx";
  if (code < 400) return "status-3xx";
  if (code < 500) return "status-4xx";
  return "status-5xx";
}

function renderFlowList() {
  const el = $("#flow-list");
  const flows = [...state.flows].reverse();
  if (flows.length === 0) {
    el.innerHTML = `<div class="empty-state">No traffic yet.<br>Point a device's proxy at your VPS and browse somewhere.</div>`;
    return;
  }
  el.innerHTML = flows.map((f) => {
    const req = f.request || {};
    const res = f.response;
    const url = req.url || "";
    const shortUrl = url.length > 70 ? url.slice(0, 70) + "…" : url;
    const statusText = f.intercepted ? "⏸ paused" : (res ? res.status_code : (f.error ? "error" : "…"));
    return `
      <div class="flow-row ${f.intercepted ? "intercepted" : ""}" data-id="${f.id}">
        <div class="flow-row-top">
          <span class="badge ${methodBadgeClass(req.method)}">${req.method || "?"}</span>
          <span class="status-chip ${statusClass(res && res.status_code)}">${statusText}</span>
        </div>
        <div class="flow-url">${escapeHtml(shortUrl)}</div>
        <div class="flow-meta">${new Date((f.timestamp_start || 0) * 1000).toLocaleTimeString()}</div>
      </div>`;
  }).join("");

  $$(".flow-row").forEach((row) => {
    row.addEventListener("click", () => openFlowDetail(row.dataset.id));
  });
}

function escapeHtml(s) {
  return (s || "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function openFlowDetail(id) {
  const f = state.flowsById[id];
  if (!f) return;
  const req = f.request || {};
  const res = f.response;
  const reqBody = b64decode(req.body_b64);
  const resBody = res ? b64decode(res.body_b64) : "";

  let html = `
    <h3>Request</h3>
    <pre>${escapeHtml(req.method)} ${escapeHtml(req.url)} ${escapeHtml(req.http_version || "")}
${escapeHtml(headersToText(req.headers))}

${escapeHtml(reqBody)}</pre>`;

  if (res) {
    html += `
    <h3>Response</h3>
    <pre>${res.status_code} ${escapeHtml(res.reason || "")}
${escapeHtml(headersToText(res.headers))}

${escapeHtml(resBody)}</pre>`;
  } else if (f.error) {
    html += `<h3>Error</h3><pre>${escapeHtml(f.error)}</pre>`;
  }

  if (f.intercepted) {
    html += `
      <h3>Intercepted — edit before forwarding</h3>
      <textarea id="int-edit-method" class="mono-area" rows="1">${escapeHtml(req.method)}</textarea>
      <textarea id="int-edit-url" class="mono-area" rows="2" style="margin-top:6px">${escapeHtml(req.url)}</textarea>
      <textarea id="int-edit-headers" class="mono-area" rows="4" style="margin-top:6px">${escapeHtml(headersToText(req.headers))}</textarea>
      <textarea id="int-edit-body" class="mono-area" rows="5" style="margin-top:6px">${escapeHtml(reqBody)}</textarea>
      <div class="sheet-actions">
        <button class="btn-secondary" id="btn-drop">Drop</button>
        <button class="btn-primary" id="btn-forward" style="margin-top:0">Forward</button>
      </div>`;
  }

  html += `
    <div class="sheet-actions">
      <button class="btn-secondary" id="btn-send-to-repeater">Send to Repeater</button>
    </div>`;

  $("#sheet-body").innerHTML = html;
  showSheet();

  const sendBtn = $("#btn-send-to-repeater");
  if (sendBtn) sendBtn.addEventListener("click", () => {
    loadIntoRepeater(req);
    closeSheet();
    $$(".tabbar-btn").forEach((b) => b.classList.toggle("active", b.dataset.tab === "repeater"));
    $$(".tab-pane").forEach((p) => p.classList.add("hidden"));
    $("#tab-repeater").classList.remove("hidden");
  });

  const fwdBtn = $("#btn-forward");
  if (fwdBtn) fwdBtn.addEventListener("click", async () => {
    const edits = {
      method: $("#int-edit-method").value.trim(),
      url: $("#int-edit-url").value.trim(),
      headers: textToHeaders($("#int-edit-headers").value),
      body_b64: b64encode($("#int-edit-body").value),
    };
    await fetchApi(`/api/intercept/${id}/forward`, { method: "POST", body: edits });
    closeSheet();
  });

  const dropBtn = $("#btn-drop");
  if (dropBtn) dropBtn.addEventListener("click", async () => {
    await fetchApi(`/api/intercept/${id}/drop`, { method: "POST" });
    closeSheet();
  });
}

function showSheet() {
  $("#sheet-backdrop").classList.remove("hidden");
  $("#sheet-detail").classList.remove("hidden");
}
function closeSheet() {
  $("#sheet-backdrop").classList.add("hidden");
  $("#sheet-detail").classList.add("hidden");
}
$("#sheet-backdrop").addEventListener("click", closeSheet);

$("#inp-intercept").addEventListener("change", async (e) => {
  const scope = $("#inp-scope").value.trim();
  await fetchApi("/api/intercept/toggle", { method: "POST", params: { enabled: e.target.checked, scope } });
});

$("#btn-clear-flows").addEventListener("click", async () => {
  await fetchApi("/api/flows", { method: "DELETE" });
  state.flows = [];
  state.flowsById = {};
  renderFlowList();
});

// ---------------------------------------------------------------------------
// REPEATER TAB
// ---------------------------------------------------------------------------

function addRepeaterTab(initial) {
  const tab = initial || { method: "GET", url: "", headers: "", body: "", response: null };
  state.repeaterTabs.push(tab);
  state.activeRepTab = state.repeaterTabs.length - 1;
  renderRepeaterTabs();
  loadRepeaterEditor();
}

function renderRepeaterTabs() {
  const el = $("#repeater-tabstrip");
  el.innerHTML = state.repeaterTabs.map((t, i) =>
    `<div class="rep-tab-chip ${i === state.activeRepTab ? "active" : ""}" data-i="${i}">${i + 1}</div>`
  ).join("");
  $$(".rep-tab-chip").forEach((chip) => {
    chip.addEventListener("click", () => {
      saveRepeaterEditor();
      state.activeRepTab = Number(chip.dataset.i);
      renderRepeaterTabs();
      loadRepeaterEditor();
    });
  });
}

function saveRepeaterEditor() {
  const t = state.repeaterTabs[state.activeRepTab];
  if (!t) return;
  t.method = $("#rep-method").value;
  t.url = $("#rep-url").value;
  t.headers = $("#rep-headers").value;
  t.body = $("#rep-body").value;
}

function loadRepeaterEditor() {
  const t = state.repeaterTabs[state.activeRepTab];
  if (!t) return;
  $("#rep-method").value = t.method;
  $("#rep-url").value = t.url;
  $("#rep-headers").value = t.headers;
  $("#rep-body").value = t.body;
  $("#rep-response").innerHTML = t.response || "";
}

function loadIntoRepeater(req) {
  addRepeaterTab({
    method: req.method,
    url: req.url,
    headers: headersToText(req.headers),
    body: b64decode(req.body_b64),
    response: null,
  });
}

$("#btn-rep-new").addEventListener("click", () => {
  saveRepeaterEditor();
  addRepeaterTab();
});

$("#btn-rep-send").addEventListener("click", async () => {
  saveRepeaterEditor();
  const t = state.repeaterTabs[state.activeRepTab];
  const btn = $("#btn-rep-send");
  btn.textContent = "Sending…";
  btn.disabled = true;
  try {
    const resp = await fetchApi("/api/repeater/send", {
      method: "POST",
      body: {
        method: t.method,
        url: t.url,
        headers: textToHeaders(t.headers),
        body_b64: b64encode(t.body),
      },
    });
    const data = await resp.json();
    let html;
    if (!data.ok) {
      html = `<span class="response-status" style="color:var(--err)">ERROR</span>\n${escapeHtml(data.error)}`;
    } else {
      const bodyText = b64decode(data.body_b64);
      html = `<span class="response-status ${statusClass(data.status_code)}">${data.status_code} ${escapeHtml(data.reason || "")} · ${data.elapsed_ms}ms</span>\n\n${escapeHtml(headersToText(data.headers))}\n\n${escapeHtml(bodyText)}`;
    }
    t.response = html;
    $("#rep-response").innerHTML = html;
  } catch (e) {
    $("#rep-response").textContent = "Request failed: " + e.message;
  } finally {
    btn.textContent = "Send";
    btn.disabled = false;
  }
});

// ---------------------------------------------------------------------------
// INTRUDER TAB
// ---------------------------------------------------------------------------

function parsePayloadSets(text) {
  return text
    .split(/\n\s*\n/)          // blank line separates sets
    .map((block) => block.split("\n").map((l) => l).filter((l) => l.length > 0))
    .filter((set) => set.length > 0);
}

function renderIntruderResults() {
  const el = $("#int-results");
  const sorted = [...state.intruderResults].sort((a, b) => a.index - b.index);
  el.innerHTML = sorted.map((r) => `
    <div class="result-row">
      <span class="idx">#${r.index}</span>
      <span class="${statusClass(r.status_code)}">${r.status_code ?? "err"}</span>
      <span class="len">${r.length ?? "-"}b</span>
      <span class="payloads">${escapeHtml((r.payloads || []).join(" | "))}</span>
    </div>`).join("");
}

$("#btn-int-run").addEventListener("click", async () => {
  const payloadSets = parsePayloadSets($("#int-payloads").value);
  if (payloadSets.length === 0) {
    alert("Add at least one payload list.");
    return;
  }
  state.intruderResults = [];
  renderIntruderResults();
  const btn = $("#btn-int-run");
  btn.textContent = "Running…";
  btn.disabled = true;
  $("#int-progress").textContent = "Attack running…";

  try {
    const resp = await fetchApi("/api/intruder/run", {
      method: "POST",
      body: {
        method: $("#int-method").value,
        url: $("#int-url").value,
        headers: textToHeaders($("#int-headers").value),
        body: $("#int-body").value,
        attack_type: $("#int-attack").value,
        payload_sets: payloadSets,
        concurrency: Number($("#int-concurrency").value) || 5,
      },
    });
    const data = await resp.json();
    if (data.ok) {
      state.intruderResults = data.results;
      renderIntruderResults();
      $("#int-progress").textContent = `Done — ${data.total} requests.`;
    } else {
      $("#int-progress").textContent = "Attack failed: " + (data.detail || "unknown error");
    }
  } catch (e) {
    $("#int-progress").textContent = "Attack failed: " + e.message;
  } finally {
    btn.textContent = "Start attack";
    btn.disabled = false;
  }
});
