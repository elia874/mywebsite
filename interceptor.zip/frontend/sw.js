const CACHE = "interceptor-shell-v1";
const SHELL = ["./index.html", "./style.css", "./app.js", "./manifest.json"];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)));
  self.skipWaiting();
});

self.addEventListener("activate", (e) => {
  e.waitUntil(self.clients.claim());
});

self.addEventListener("fetch", (e) => {
  // Only cache the app shell itself; never cache API/WebSocket calls to the VPS.
  const url = new URL(e.request.url);
  if (SHELL.some((s) => url.pathname.endsWith(s.replace("./", "")))) {
    e.respondWith(
      caches.match(e.request).then((cached) => cached || fetch(e.request))
    );
  }
});
