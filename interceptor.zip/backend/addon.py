"""
burpclone addon.py
-------------------
A mitmproxy addon that runs an embedded FastAPI server inside mitmproxy's own
asyncio event loop. Gives you:

  - Live traffic feed over WebSocket (Proxy tab)
  - Intercept: pause / edit / forward / drop requests before they go out
  - Repeater: resend & edit any request, independent of the proxy
  - Intruder: automated fuzzing (sniper / battering-ram / pitchfork / cluster-bomb)

Run with:
    mitmdump -s addon.py --set api_token=CHANGE_ME --set api_port=8081 -p 8080

  -p 8080        -> the actual MITM proxy port (point your phone/browser here)
  api_port=8081  -> the control API/WebSocket port (your app connects here)
  api_token      -> shared secret, required on every API call (query param or header)
"""

import asyncio
import base64
import itertools
import time
import uuid
from typing import Optional

import httpx
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Header, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

from mitmproxy import ctx, http


# --------------------------------------------------------------------------
# In-memory state (fine for a personal tool; swap for sqlite if you need
# history to survive restarts)
# --------------------------------------------------------------------------

class State:
    def __init__(self):
        self.flows: dict[str, dict] = {}       # flow_id -> serialized flow
        self.flow_order: list[str] = []        # insertion order, capped
        self.max_flows = 2000

        self.intercept_enabled = False
        self.intercept_scope: Optional[str] = None   # substring filter, None = all
        self.pending: dict[str, asyncio.Event] = {}   # flow_id -> release event
        self.pending_flow_obj: dict[str, http.HTTPFlow] = {}
        self.pending_action: dict[str, str] = {}      # "forward" | "drop"
        self.pending_edits: dict[str, dict] = {}       # edits to apply before forward

        self.ws_clients: set[WebSocket] = set()

    def add_flow(self, flow_dict: dict):
        fid = flow_dict["id"]
        self.flows[fid] = flow_dict
        self.flow_order.append(fid)
        if len(self.flow_order) > self.max_flows:
            old = self.flow_order.pop(0)
            self.flows.pop(old, None)


state = State()
API_TOKEN = "changeme"  # overridden by --set api_token=...
API_PORT = 8081


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------

def b64(data: bytes) -> str:
    return base64.b64encode(data or b"").decode("ascii")


def serialize_request(req: http.Request) -> dict:
    return {
        "method": req.method,
        "url": req.pretty_url,
        "http_version": req.http_version,
        "headers": list(req.headers.items(multi=True)),
        "body_b64": b64(req.raw_content),
    }


def serialize_response(resp: Optional[http.Response]) -> Optional[dict]:
    if resp is None:
        return None
    return {
        "status_code": resp.status_code,
        "reason": resp.reason,
        "http_version": resp.http_version,
        "headers": list(resp.headers.items(multi=True)),
        "body_b64": b64(resp.raw_content),
    }


def serialize_flow(flow: http.HTTPFlow) -> dict:
    return {
        "id": flow.id,
        "timestamp_start": flow.request.timestamp_start if flow.request else time.time(),
        "client_address": str(flow.client_conn.peername[0]) if flow.client_conn and flow.client_conn.peername else "",
        "request": serialize_request(flow.request),
        "response": serialize_response(flow.response),
        "intercepted": False,
        "error": str(flow.error) if flow.error else None,
    }


async def broadcast(event: dict):
    dead = []
    for ws in state.ws_clients:
        try:
            await ws.send_json(event)
        except Exception:
            dead.append(ws)
    for ws in dead:
        state.ws_clients.discard(ws)


def check_token(token: Optional[str]):
    if token != API_TOKEN:
        raise HTTPException(status_code=401, detail="bad token")


# --------------------------------------------------------------------------
# mitmproxy addon hooks
# --------------------------------------------------------------------------

class BurpcloneAddon:
    def load(self, loader):
        loader.add_option("api_token", str, "changeme", "Shared secret for the control API")
        loader.add_option("api_port", int, 8081, "Port for the control API/WebSocket")

    def configure(self, updated):
        global API_TOKEN, API_PORT
        API_TOKEN = ctx.options.api_token
        API_PORT = ctx.options.api_port

    def running(self):
        # Start the embedded API server on mitmproxy's own asyncio loop
        loop = asyncio.get_event_loop()
        loop.create_task(self._start_api())

    async def _start_api(self):
        config = uvicorn.Config(app, host="0.0.0.0", port=API_PORT, log_level="warning")
        server = uvicorn.Server(config)
        ctx.log.info(f"[burpclone] control API listening on :{API_PORT}")
        await server.serve()

    async def requestheaders(self, flow: http.HTTPFlow):
        if not state.intercept_enabled:
            return
        if state.intercept_scope and state.intercept_scope not in flow.request.pretty_url:
            return

        fid = flow.id
        ev = asyncio.Event()
        state.pending[fid] = ev
        state.pending_flow_obj[fid] = flow

        flow_dict = serialize_flow(flow)
        flow_dict["intercepted"] = True
        state.add_flow(flow_dict)
        await broadcast({"type": "intercepted", "flow": flow_dict})

        await ev.wait()  # blocks this request until user forwards/drops via API

        action = state.pending_action.pop(fid, "forward")
        edits = state.pending_edits.pop(fid, None)
        state.pending.pop(fid, None)
        state.pending_flow_obj.pop(fid, None)

        if action == "drop":
            flow.kill()
            return

        if edits:
            if "method" in edits:
                flow.request.method = edits["method"]
            if "url" in edits:
                flow.request.url = edits["url"]
            if "headers" in edits:
                flow.request.headers.clear()
                for k, v in edits["headers"]:
                    flow.request.headers.add(k, v)
            if "body_b64" in edits:
                flow.request.raw_content = base64.b64decode(edits["body_b64"])

    async def response(self, flow: http.HTTPFlow):
        flow_dict = serialize_flow(flow)
        state.add_flow(flow_dict)
        await broadcast({"type": "flow", "flow": flow_dict})

    async def error(self, flow: http.HTTPFlow):
        flow_dict = serialize_flow(flow)
        state.add_flow(flow_dict)
        await broadcast({"type": "flow", "flow": flow_dict})


addons = [BurpcloneAddon()]


# --------------------------------------------------------------------------
# Embedded FastAPI app (the control API your phone app talks to)
# --------------------------------------------------------------------------

app = FastAPI(title="burpclone control API")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/flows")
def get_flows(token: str = Query(...), limit: int = 200):
    check_token(token)
    ids = state.flow_order[-limit:]
    return [state.flows[i] for i in ids if i in state.flows]


@app.delete("/api/flows")
def clear_flows(token: str = Query(...)):
    check_token(token)
    state.flows.clear()
    state.flow_order.clear()
    return {"ok": True}


@app.get("/api/intercept/state")
def intercept_state(token: str = Query(...)):
    check_token(token)
    return {
        "enabled": state.intercept_enabled,
        "scope": state.intercept_scope,
        "pending": list(state.pending.keys()),
    }


@app.post("/api/intercept/toggle")
def intercept_toggle(token: str = Query(...), enabled: bool = Query(...), scope: Optional[str] = Query(None)):
    check_token(token)
    state.intercept_enabled = enabled
    state.intercept_scope = scope or None
    return {"ok": True}


@app.post("/api/intercept/{flow_id}/forward")
async def intercept_forward(flow_id: str, token: str = Query(...), edits: Optional[dict] = None):
    check_token(token)
    if flow_id not in state.pending:
        raise HTTPException(404, "no such pending flow")
    if edits:
        state.pending_edits[flow_id] = edits
    state.pending_action[flow_id] = "forward"
    state.pending[flow_id].set()
    return {"ok": True}


@app.post("/api/intercept/{flow_id}/drop")
async def intercept_drop(flow_id: str, token: str = Query(...)):
    check_token(token)
    if flow_id not in state.pending:
        raise HTTPException(404, "no such pending flow")
    state.pending_action[flow_id] = "drop"
    state.pending[flow_id].set()
    return {"ok": True}


@app.websocket("/api/ws")
async def ws_endpoint(websocket: WebSocket, token: str = Query(...)):
    if token != API_TOKEN:
        await websocket.close(code=4401)
        return
    await websocket.accept()
    state.ws_clients.add(websocket)
    try:
        while True:
            await websocket.receive_text()  # keepalive pings from client
    except WebSocketDisconnect:
        pass
    finally:
        state.ws_clients.discard(websocket)


# ---------------------------- Repeater -------------------------------------
# Sends a request directly (not necessarily through the MITM proxy) so it
# works even for hosts you're not actively intercepting.

@app.post("/api/repeater/send")
async def repeater_send(payload: dict, token: str = Query(...)):
    check_token(token)
    method = payload.get("method", "GET")
    url = payload["url"]
    headers = payload.get("headers", [])
    body_b64 = payload.get("body_b64", "")
    body = base64.b64decode(body_b64) if body_b64 else b""
    verify_tls = payload.get("verify_tls", False)

    start = time.time()
    try:
        async with httpx.AsyncClient(verify=verify_tls, follow_redirects=False, timeout=30) as client:
            resp = await client.request(method, url, headers=dict(headers), content=body)
        elapsed_ms = int((time.time() - start) * 1000)
        return {
            "ok": True,
            "status_code": resp.status_code,
            "reason": resp.reason_phrase,
            "headers": list(resp.headers.items()),
            "body_b64": b64(resp.content),
            "elapsed_ms": elapsed_ms,
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}


# ---------------------------- Intruder --------------------------------------
# Payload positions are marked in the raw request template with §...§ markers,
# e.g. url = "https://target.com/user?id=§FUZZ§"
# attack_type: sniper | battering_ram | pitchfork | cluster_bomb

MARKER = "\u00a7"  # §


def find_positions(template: str) -> list[str]:
    parts = template.split(MARKER)
    # positions are at odd indices: text § POS § text § POS § text...
    return [parts[i] for i in range(1, len(parts), 2)]


def render(template: str, values: list[str]) -> str:
    parts = template.split(MARKER)
    out = []
    val_i = 0
    for i, part in enumerate(parts):
        if i % 2 == 0:
            out.append(part)
        else:
            out.append(values[val_i])
            val_i += 1
    return "".join(out)


def build_combinations(payload_sets: list[list[str]], attack_type: str):
    n_positions = len(payload_sets)
    if attack_type == "sniper":
        # each position fuzzed alone, others held at first value of their own set
        base = [s[0] if s else "" for s in payload_sets]
        combos = []
        for i, s in enumerate(payload_sets):
            for v in s:
                c = base.copy()
                c[i] = v
                combos.append(c)
        return combos
    elif attack_type == "battering_ram":
        # same single payload list used in every position simultaneously
        s = payload_sets[0]
        return [[v] * n_positions for v in s]
    elif attack_type == "pitchfork":
        # parallel iteration, all lists same length
        length = min(len(s) for s in payload_sets)
        return [[payload_sets[i][j] for i in range(n_positions)] for j in range(length)]
    elif attack_type == "cluster_bomb":
        return [list(c) for c in itertools.product(*payload_sets)]
    else:
        raise ValueError("unknown attack_type")


@app.post("/api/intruder/run")
async def intruder_run(payload: dict, token: str = Query(...)):
    check_token(token)
    method = payload.get("method", "GET")
    url_template = payload["url"]
    header_templates: list[tuple[str, str]] = payload.get("headers", [])
    body_template = payload.get("body", "")
    attack_type = payload.get("attack_type", "sniper")
    payload_sets: list[list[str]] = payload.get("payload_sets", [])
    concurrency = min(int(payload.get("concurrency", 5)), 20)
    verify_tls = payload.get("verify_tls", False)

    if not payload_sets:
        raise HTTPException(400, "payload_sets required")

    combos = build_combinations(payload_sets, attack_type)
    results = []
    sem = asyncio.Semaphore(concurrency)

    async def run_one(idx: int, values: list[str]):
        async with sem:
            url = render(url_template, values)
            headers = {k: render(v, values) for k, v in header_templates}
            body = render(body_template, values).encode() if body_template else b""
            start = time.time()
            try:
                async with httpx.AsyncClient(verify=verify_tls, follow_redirects=False, timeout=20) as client:
                    resp = await client.request(method, url, headers=headers, content=body)
                elapsed_ms = int((time.time() - start) * 1000)
                result = {
                    "index": idx,
                    "payloads": values,
                    "status_code": resp.status_code,
                    "length": len(resp.content),
                    "elapsed_ms": elapsed_ms,
                    "error": None,
                }
            except Exception as e:
                result = {
                    "index": idx,
                    "payloads": values,
                    "status_code": None,
                    "length": None,
                    "elapsed_ms": None,
                    "error": str(e),
                }
            results.append(result)
            await broadcast({"type": "intruder_result", "result": result})

    await asyncio.gather(*[run_one(i, v) for i, v in enumerate(combos)])
    results.sort(key=lambda r: r["index"])
    return {"ok": True, "total": len(results), "results": results}
