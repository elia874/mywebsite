# Interceptor — mobile MITM proxy toolkit

A Burp-Suite-style toolkit built for bug bounty work: an intercepting proxy
(running on your VPS via mitmproxy), plus Repeater and Intruder, controlled
from a mobile web app that installs to your phone's home screen like a native app.

```
┌────────────┐   proxy traffic    ┌──────────────────────────┐
│ your phone │ ───────────────────▶  VPS: mitmproxy (:8080)   │
│  (target   │                    │   + addon.py control API  │
│  browser)  │                    │     (:8081, WS + REST)    │
└────────────┘                    └──────────────┬─────────────┘
                                                   │
┌────────────┐   HTTPS/WSS control calls           │
│ Interceptor│ ◀─────────────────────────────────┘
│  PWA app   │
└────────────┘
```

Two *separate* things happen on your phone:
1. **Traffic you want to inspect** gets proxied through the VPS (`:8080`) — this is standard MITM proxy setup, same as Burp/Charles/Reqable.
2. **The Interceptor app itself** talks to the control API (`:8081`) to show you that traffic and let you intercept/repeat/fuzz it.

---

## 1. Backend setup (on your VPS)

```bash
# copy the backend/ folder to your VPS, e.g. /opt/burpclone/backend
cd /opt/burpclone/backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

Run it directly to test:

```bash
mitmdump -s addon.py --set api_token=SOME_LONG_RANDOM_SECRET --set api_port=8081 -p 8080
```

- `-p 8080` — the actual MITM proxy port. Point your phone's proxy settings here.
- `api_port=8081` — the control API/WebSocket port. The app connects here.
- `api_token` — **change this**. It's the only thing standing between the internet and full control of your proxy. Generate one with `openssl rand -hex 32`.

Once it's running, install it permanently:

```bash
sudo cp burpclone.service /etc/systemd/system/
sudo nano /etc/systemd/system/burpclone.service   # fix YOUR_VPS_USER and the token
sudo systemctl daemon-reload
sudo systemctl enable --now burpclone
sudo systemctl status burpclone
```

### Firewall / exposure — read this

Both ports are talking to the open internet by default. Two extra hardening steps you should actually do before relying on this against real targets:

- **Lock down :8081 (the API) to your own IP**, e.g. with `ufw allow from YOUR.HOME.IP to any port 8081`, or better, put it behind [Tailscale](https://tailscale.com) / WireGuard so it's never internet-facing at all.
- **Put TLS in front of :8081** so the app can use `wss://` (required for the PWA on iOS, and just good practice since your token travels in the URL). Easiest: run [Caddy](https://caddyhq.com) or nginx + certbot as a reverse proxy in front of it with a real domain, e.g. `interceptor-api.yourdomain.com` → `127.0.0.1:8081`. Leave :8080 (the actual proxy) as plain HTTP — that's normal, MITM proxies always are.

### HTTPS interception (installing the CA cert)

To intercept HTTPS traffic (not just HTTP), the device being proxied needs to trust mitmproxy's CA:

1. With mitmdump running, visit `http://mitm.it` **from a device configured to use the proxy**.
2. Download and install the certificate for your OS (iOS/Android/etc).
3. On iOS: also go to Settings → General → About → Certificate Trust Settings and enable full trust for the mitmproxy root cert.

This is standard for any MITM proxy (Burp, Charles, Reqable all require the same step) — it's not something the app can skip.

---

## 2. Frontend setup (the phone app)

The `frontend/` folder is a static site (no build step). Host it anywhere with HTTPS — the same VPS is fine:

```bash
# quick option: serve with nginx or Caddy alongside your API reverse proxy
# e.g. Caddyfile:
#   interceptor.yourdomain.com {
#     root * /opt/burpclone/frontend
#     file_server
#   }
#   interceptor-api.yourdomain.com {
#     reverse_proxy 127.0.0.1:8081
#   }
```

Then on your phone:

1. Open `https://interceptor.yourdomain.com` in Safari/Chrome.
2. Enter your API address (`interceptor-api.yourdomain.com`, no `https://` prefix needed) and the token you set in `api_token`.
3. Tap **Connect**.
4. iOS: tap Share → **Add to Home Screen**. Android: browser menu → **Install app**. It now opens full-screen like a native app.

## 3. Configuring the device you want to proxy

This is a separate device (or the same phone, in a second network profile) from the one running the Interceptor app — whatever you're pointing at your target:

- **Wi-Fi proxy settings** → manual → host = your VPS IP, port = `8080` (the mitmproxy port, not 8081).
- Install the CA cert as described above if you need HTTPS.

## 4. Using it

- **Proxy tab** — live traffic feed. Toggle **Intercept** to pause requests before they go out; tap a paused (amber) row to edit method/URL/headers/body, then Forward or Drop. Tap any row → **Send to Repeater** to carry it over.
- **Repeater tab** — multiple tabs (chips at top), edit request, hit Send, see raw response below.
- **Intruder tab** — mark fuzz positions in the URL/body with `§...§`, e.g. `?id=§1§`. Add payload lists in the box, separating each position's list with a blank line. Pick an attack type:
  - **Sniper** — fuzzes one position at a time, others stay at their first value.
  - **Battering ram** — same payload in every position at once.
  - **Pitchfork** — walks multiple lists in parallel (list 1 with list 1, list 2 with list 2, index by index).
  - **Cluster bomb** — every combination of every list.

---

## What's genuinely here vs. what's a stub

Working end-to-end: live traffic capture, intercept/edit/forward/drop, Repeater, Intruder with all 4 attack types, WebSocket live updates, PWA install.

Not built (roadmap if you want to extend it): active vulnerability scanner, response diffing/match-replace rules, WebSocket traffic interception (currently HTTP/S only), request history search/filter beyond scope substring, payload processing rules (encoders, generators beyond plain wordlists), auth beyond a single shared token.

## Security note

This tool gives whoever holds the token full read/write control over intercepted traffic. Treat the token like a root password — rotate it if you think it's leaked, and don't commit it to a public repo.
